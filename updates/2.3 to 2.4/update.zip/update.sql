UPDATE `general_settings` SET `value` = '2.4' WHERE `general_settings`.`general_settings_id` = 79;
INSERT INTO `general_settings` (`general_settings_id`, `type`, `value`) VALUES (NULL, 'email_notification_on_express_interest', 'off');
INSERT INTO `general_settings` (`general_settings_id`, `type`, `value`) VALUES (NULL, 'email_notification_on_sending_message', 'off');
